import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min.js";
import "./App.css";
import AppRoutes from "./Routes/Routes";

function App() {
  return <AppRoutes />;
}
export default App;